package topicmodels.correspondenceModels;

public class corrLDA_Gibbs_test {

}
