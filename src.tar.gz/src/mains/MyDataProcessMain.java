package mains;

import Application.DataAnalysis;

public class MyDataProcessMain {
	public static void  main(String[] args){
		DataAnalysis ds = new DataAnalysis();
		String blackSeed = "./data/stat/1210black_seed.txt";
		ds.loadFile(blackSeed);
		ds.analyze();
		
	}

}
